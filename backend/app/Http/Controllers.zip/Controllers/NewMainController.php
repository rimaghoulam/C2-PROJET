<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Controllers\NewFunctions;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request; 
use Illuminate\Http\Response;
use Session;
use Redirect;


class NewMainController extends Controller
{
    protected $NewFunctions;
    public function __construct(NewFunctions $NewFunctions)
    {
        $this->NewFunctions = $NewFunctions;
    } 
    
    public function Forget_Password($request)
    {
        $email = $request->input('email');
        $forget_pass = $this->NewFunctions->forget_password($email);
        return json_encode($forget_pass);
       }
       
    public function Get_Dashboard($request)
    {
        $userid = $request->input('userid'); $token = $request->input('token');
        $get_dashboard = $this->NewFunctions->get_dashboard($userid,$token);
        return json_encode($get_dashboard);
       }
       
    public function Get_Challenge($request)
    {
        $userid = $request->input('userid'); $token = $request->input('token');
        $get_challenge = $this->NewFunctions->get_challenge($userid,$token);
        return json_encode($get_challenge);
       }
       
    
    public function Get_Internship($request)
    {
        $userid = $request->input('userid'); $token = $request->input('token');
        $get_internship = $this->NewFunctions->get_internship($userid,$token);
        return json_encode($get_internship);
       }
       
       public function Edit_Challenge($request)
    {
        $userid = $request->input('userid');
	    $token = $request->input('token');
	    $jobid = $request->input('jobid');
	    $chname = $request->input('chname');
	    $chtype = $request->input('chtype');
	    $chdesc = $request->input('chdesc');
	    $chapproach = $request->input('chapproach');
	    $chspec = $request->input('chspec');
	    $chtime = $request->input('chtime');
	    $chaffected = $request->input('chaffected');
	    $chaffspec = $request->input('chaffspec');
	    $chcost = $request->input('chcost');
	    $chcostspec = $request->input('chcostspec');
	    $chhear = $request->input('chhear');
        $edit_challenge = $this->NewFunctions->edit_challenge($userid, $token, $jobid, $chname,$chtype,$chdesc,$chapproach,$chspec,$chtime,$chaffected,$chaffspec,$chcost,$chcostspec,$chhear);
        return json_encode($edit_challenge);
       }
       
    
    public function Edit_Internship($request)
    {
        $userid = $request->input('userid');
        $token = $request->input('token');
        $jobid = $request->input('jobid');
        $startdate = $request->input('startdate');
        $positionOutline = $request->input('positionOutline');
        $location = $request->input('location');
        $listDocuments = $request->input('listDocuments');
        $enddate = $request->input('enddate');
        $jobTitle = $request->input('jobTitle');
        $experience = $request->input('experience');
        $department = $request->input('department');
        $compensationSalary = $request->input('compensationSalary');
        $companydesc = $request->input('companydesc');
        $categorieStudent = $request->input('categorieStudent');
        $edit_internship = $this->NewFunctions->edit_internship($userid,$token,$jobid,$startdate,$positionOutline,$location,$listDocuments,$enddate,$jobTitle,$experience,$department,$compensationSalary,$companydesc,$categorieStudent);
        return json_encode($edit_internship);
       }
       
       
    public function Get_All_Users($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token');
          $all_users = $this->NewFunctions->get_all_users($userid,$token);
          return json_encode($all_users);
        }
        
    public function Get_User_Posted_Job($request)
    {
        $adminid = $request->input('adminid'); $token = $request->input('token'); $userid = $request->input('userid');
        $get_user_posted_job = $this->NewFunctions->get_user_posted_job($adminid,$token,$userid);
        return json_encode($get_user_posted_job);
       }
        
    public function Assign_Job($request)
        {
          $adminid = $request->input('adminid'); $token = $request->input('token'); $userid = $request->input('userid'); $jobid = $request->input('jobid');
          $assign_job = $this->NewFunctions->assign_job($adminid,$token,$userid,$jobid);
          return json_encode($assign_job);
        }
        
    public function Get_Dashboard_Assigned_To_Me($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token');
          $get_dashboard_assigned_to_me = $this->NewFunctions->get_dashboard_assigned_to_me($userid,$token);
          return json_encode($get_dashboard_assigned_to_me);
        }
        
    public function Get_Challenge_Assigned_To_Me($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token');
          $get_challenge_assigned_to_me = $this->NewFunctions->get_challenge_assigned_to_me($userid,$token);
          return json_encode($get_challenge_assigned_to_me);
        }
        
    public function Get_Internship_Assigned_To_Me($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token');
          $get_internship_assigned_to_me = $this->NewFunctions->get_internship_assigned_to_me($userid,$token);
          return json_encode($get_internship_assigned_to_me);
        }
        
    public function Get_User_Info_Company($request)
        {
          $myid = $request->input('myid'); $token = $request->input('token'); $userid = $request->input('userid');
          $get_user_info_company = $this->NewFunctions->get_user_info_company($myid,$token,$userid);
          return json_encode($get_user_info_company);
        }
        
    public function Get_Job_Details_Byid($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token'); $jobid = $request->input('jobid');
          $get_job_details_byid = $this->NewFunctions->get_job_details_byid($userid,$token,$jobid);
          return json_encode($get_job_details_byid);
        }
        
    public function Post_Comment($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token'); $msg = $request->input('msg'); $jobid = $request->input('jobid'); $reply = $request->input('reply');
          $post_comment = $this->NewFunctions->post_comment($userid,$token,$msg,$jobid,$reply);
          return json_encode($post_comment);
        }
        
    public function Get_Count_Comments_By_Jobid($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token'); $jobid = $request->input('jobid');
          $get_count_comments_by_jobid = $this->NewFunctions->get_count_comments_by_jobid($userid,$token,$jobid);
          return json_encode($get_count_comments_by_jobid);
        }
        
    public function Get_All_Documents($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token');
          $get_all_documents = $this->NewFunctions->get_all_documents($userid,$token);
          return json_encode($get_all_documents);
        }
        
    public function Delete_Document($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token'); $document_name = $request->input('documentname'); $document_type = $request->input('documenttype'); $id_row = $request->input('idrow');
          $delete_document = $this->NewFunctions->delete_document($userid,$token,$document_name,$document_type,$id_row);
          return json_encode($delete_document);
        }
        
    public function Get_Notifications($request)
        {
          $userid = $request->input('userid'); $token = $request->input('token');
          $get_notifications = $this->NewFunctions->get_notifications($userid,$token);
          return json_encode($get_notifications);
        }
        
    public function Fill_Data($request)
        {
          $fill_data = $this->NewFunctions->fill_data();
          return json_encode($fill_data);
        }
    
}

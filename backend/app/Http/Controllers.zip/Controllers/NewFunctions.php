<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Functions;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request; 
use Illuminate\Http\Response;
use App\Http\Requests;
use DateTime;
use Mail;
use Hash;

use Str;


class NewFunctions extends Controller
{

    protected $Functions;
    public function __construct(Functions $Functions)
    {
        $this->Functions = $Functions;
    }

    public function forget_password($email){
        $search_results = DB::table('basic_user')
                            ->select('*')
                            ->where("user_email","=", $email)
                            ->get();
                            
       if( count($search_results) == 1 ) {
           
            date_default_timezone_set("Asia/Beirut");
            $date = date("Y/m/d H:i:s");
            $generate_token = $this->Functions->generate_token();
         
            DB::table('reset_password')->insert([
                      'email' => $email,'token' => $generate_token ,'created_at' => $date, 'submit' => 0,
            ]);
            
       }
       
       else return "email not found";
    }
    
    public function get_dashboard($userid,$token){
        $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        $token=md5($token);
        
        if($check_token_time){
           
            $user_sme_id = $this->Functions->get_sme_id_by_user_id($userid);
              
            if(count($user_sme_id)==1){
                 
                date_default_timezone_set("Asia/Beirut");
                $date = date("Y-m-d");
                $sme_id=$user_sme_id[0]->sme_details_id;
      
                $internship_search_results = DB::table('job')
                                            ->join('internship', 'internship.internship_job_id', '=', 'job.job_id')
                                            ->select('job.*','internship.*')
                                            ->where("job_user_id","=", $userid)
                                            ->where("job_sme_id","=", $sme_id)
                                            ->where("job_type","=", "internship")
                                            ->where("internship_start_date",">=", $date)
                                            ->where("job_status","=", "PENDING REVIEW")
                                            ->orderBy('created_date', 'asc')
                                            ->get();
                                
                $challenge_search_results = DB::table('job')
                                            ->join('challenges', 'challenges.challenge_job_id', '=', 'job.job_id')
                                            ->select('job.*','challenges.*')
                                            ->where("job_user_id","=", $userid)
                                            ->where("job_sme_id","=", $sme_id)
                                            ->where("job_type","=", "challenge")
                                            ->where("job_status","=", "PENDING REVIEW")
                                            ->get();
                                           
                $result=array($internship_search_results,$challenge_search_results);
                
                return $result; 
                  
            }else{return"error 1";}
             
        }else{return"error";}
    }
    
    public function get_challenge($userid,$token){
        $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
            $user_sme_id = $this->Functions->get_sme_id_by_user_id($userid);
              
            if(count($user_sme_id)==1){
                $sme_id=$user_sme_id[0]->sme_details_id;
                $search_results = DB::table('job')
                            ->join('challenges', 'challenges.challenge_job_id', '=', 'job.job_id')
                            ->select('job.*','challenges.*')
                            ->where("job_user_id","=", $userid)
                            ->where("job_sme_id","=", $sme_id)
                            ->where("job_type","=", "challenge")
                            ->get();
        
                return $search_results; 
                  
            }else{return"error";}
             
        }else{return"error";}
    }
    
    public function get_internship($userid,$token){
    
        $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
            $user_sme_id = $this->Functions->get_sme_id_by_user_id($userid);
              
            if(count($user_sme_id)==1){
                $sme_id=$user_sme_id[0]->sme_details_id;
                $search_results = DB::table('job')
                                ->join('internship', 'internship.internship_job_id', '=', 'job.job_id')
                                ->select('job.*','internship.*')
                                ->where("job_user_id","=", $userid)
                                ->where("job_sme_id","=", $sme_id)
                                ->where("job_type","=", "internship")
                                ->get();
        
                return $search_results; 
                  
            }else{return"error";}
             
        }else{return"error";}
            
    }

    public function edit_challenge($userid, $token, $jobid, $chname,$chtype,$chdesc,$chapproach,$chspec,$chtime,$chaffected,$chaffspec,$chcost,$chcostspec,$chhear){
        $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
            $user_sme_id = $this->Functions->get_sme_id_by_user_id($userid);
            
            if(count($user_sme_id)==1){
                
                $check_user_of_job= $this->check_user_of_job($userid,$jobid);
                
                if($check_user_of_job){
                    $sme_id=$user_sme_id[0]->sme_details_id;
                    date_default_timezone_set("Asia/Beirut");
                    $date = date("Y/m/d H:i:s");
		 
		            DB::table('job')->where("job_user_id","=", $userid)
                                ->where("job_sme_id","=", $sme_id)
                                ->where('job_id','=', $jobid)
		                        ->update([
                                'updated_date' => $date,
                    ]); 
        
                    $update= DB::table('challenges')->where('challenge_job_id','=', $jobid)
                                                ->update([
                                                'challenge_name' => $chname,
                                                'challenge_type' =>  $chtype,
                                                'challenge_description' => $chdesc,
                                                'challenge_approach' => $chapproach,
                                                'challenge_approach_spec' => $chspec,
                                                'challenge_time' => $chtime,
                                                'challenge_comp_affected' => $chaffected,
                                                'challenge_comp_affected_spec' => $chaffspec,
                                                'challenge_cost' => $chcost,
                                                'challenge_cost_spec' => $chcostspec,
                                                'challenge_hear' => $chhear,
                    ]); 
        
                    return $update;
                } else{echo (" check user of job");}
            }
         } 
    }
    
    public function edit_internship($userid,$token,$jobid,$startdate,$positionOutline,$location,$listDocuments,$enddate,$jobTitle,$experience,$department,$compensationSalary,$companydesc,$categorieStudent){
        $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
            $user_sme_id = $this->Functions->get_sme_id_by_user_id($userid);
            
            if(count($user_sme_id)==1){
               
                $check_user_of_job= $this->check_user_of_job($userid,$jobid);
                
                if($check_user_of_job){
                    
                    $sme_id=$user_sme_id[0]->sme_details_id;
                    date_default_timezone_set("Asia/Beirut");
                    $date = date("Y/m/d H:i:s");
		 
		            DB::table('job')->where("job_user_id","=", $userid)
                                ->where("job_sme_id","=", $sme_id)
                                ->where('job_id','=', $jobid)
		                        ->update([
                                'updated_date' => $date,
                    ]); 
        
                    $update= DB::table('internship')->where('internship_job_id','=', $jobid)
                                                ->update([
                                                    'internship_job_title'              => $jobTitle,
                                                    'internship_outline'                => $positionOutline,
                                                    'internship_categorie_students'     => $categorieStudent,
                                                    'internship_prior_work_experience'  => $experience,
                                                    'internship_compensation_salary'    => $compensationSalary,
                                                    'internship_required_document'      => $listDocuments,
                                                    'internship_brief_description'      => $companydesc,
                                                    'internship_locations'              => $location,
                                                    'internship_start_date'             => $startdate,
                                                    'internship_end_date'               => $enddate,
                                                    'internship_department'             => $department,
                    ]); 
        
                    return $update;
                } else{echo (" check user of job");}
            }
         } 
    }

    public function get_all_users($userid, $token){
        $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
           
            $check_role= $this->Functions->return_user_role($userid);
            if(count($check_role)==1){
                
                $role=$check_role[0]->user_role_role_id;
                if($role==4){
                    
                    $student_users = DB::table('basic_user')
                                    ->join('user_role','user_role.user_role_userid','=','basic_user.user_id')
                                    ->select('basic_user.*')
                                    ->where('user_role.user_role_role_id','=','1')
                                    ->get();
                                    
                    $doctor_users = DB::table('basic_user')
                                    ->join('user_role','user_role.user_role_userid','=','basic_user.user_id')
                                    ->select('basic_user.*')
                                    ->where('user_role.user_role_role_id','=','2')
                                    ->get();
                    
                    $sme_users = DB::table('basic_user')
                                    ->join('user_role','user_role.user_role_userid','=','basic_user.user_id')
                                    ->join('sme_details','sme_details.sme_details_userid','=','basic_user.user_id')
                                    ->select('basic_user.*','sme_details.*')
                                    ->where('user_role.user_role_role_id','=','3')
                                    ->get();
                   
                    $result=array($student_users,$doctor_users,$sme_users);
                    
                 
                    return $result; 
                  
                }else{return"error role not admin";}
            }else{return"error role";}
        
        }
    }  
    
    public function get_user_posted_job($adminid,$token,$userid){
        $check_token_time= $this->Functions->check_user_token_time($adminid, $token) ;
        
        if($check_token_time){
            
            $check_role= $this->Functions->return_user_role($adminid);
            if(count($check_role)==1){
                
                $role=$check_role[0]->user_role_role_id;
                if($role==4){
                    
                    $user_sme_id = $this->Functions->get_sme_id_by_user_id($userid);
                    
                    if(count($user_sme_id)==1){
                        
                        $sme_id=$user_sme_id[0]->sme_details_id;
                
                        $user_challenges = DB::table('job')
                                ->join('challenges', 'challenges.challenge_job_id', '=', 'job.job_id')
                                ->select('job.*','challenges.*')
                                ->where("job_user_id","=", $userid)
                                ->where("job_sme_id","=", $sme_id)
                                ->where("job_type","=", "challenge")
                                ->get();
                                
                        $user_internship = DB::table('job')
                                ->join('internship', 'internship.internship_job_id', '=', 'job.job_id')
                                ->select('job.*','internship.*')
                                ->where("job_user_id","=", $userid)
                                ->where("job_sme_id","=", $sme_id)
                                ->where("job_type","=", "internship")
                                ->get();
                                
                        $user_basic_info = DB::table('basic_user')
                                ->join('sme_details', 'sme_details.sme_details_userid', '=', 'basic_user.user_id')
                                ->select('*')
                                ->where("user_id","=", $userid)
                                ->get();
                                
                        $result=array($user_challenges,$user_internship,$user_basic_info);
                    
                        return $result; 
                    }
          
                }else{return"error role not admin";}
            }else{return"error role";}
        
        }else{return"token error";}
    }
    
    public function assign_job($adminid,$token,$userid,$jobid){
        $check_token_time= $this->Functions->check_user_token_time($adminid, $token) ;
        
        if($check_token_time){
            
            $check_role= $this->Functions->return_user_role($adminid);
            if(count($check_role)==1){
                
                $role=$check_role[0]->user_role_role_id;
                if($role==4){
                    
                    $check_role= $this->Functions->return_user_role($userid);
                    
                    if(count($check_role)==1){
                         
                        $role=$check_role[0]->user_role_role_id;
                        
                        if($role==1){
                            
                    
                            date_default_timezone_set("Asia/Beirut");
                            $date = date("Y/m/d H:i:s");
                    
                            DB::table('assign_job')->insert([
                            'job_id' => $jobid,'user_id' => $userid ,'admin_id' => $adminid, 'date_assign' => $date,
                            ]);
                            return"success";
                            
                        }else{return "not an uni user";}
                    }
                }else{return"error role not admin";}
            }else{return"error role";}
        
        }else{return"error token";}
    }
    
    public function get_dashboard_assigned_to_me($userid,$token){
            $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
            if($check_token_time){
            
                $check_role= $this->Functions->return_user_role($userid);
                if(count($check_role)==1){
                
                    $role=$check_role[0]->user_role_role_id;
                    if($role==1){
                        $challenge_results = DB::table('assign_job')
                                        ->join('job', 'job.job_id', '=', 'assign_job.job_id')
                                        ->join('challenges', 'challenges.challenge_job_id', '=', 'job.job_id')
                                        ->join('sme_details', 'sme_details.sme_details_id', '=', 'job.job_sme_id')
                                        ->select('assign_job.*','job.*','challenges.*','sme_details.*')
                                        ->where("user_id","=", $userid)
                                        ->where("job_type","=", "challenge")
                                        ->where("job_status","=", "IN PROGRESS")
                                        ->get();
                                        
                        $internship_results = DB::table('assign_job')
                                        ->join('job', 'job.job_id', '=', 'assign_job.job_id')
                                        ->join('internship', 'internship.internship_job_id', '=', 'job.job_id')
                                        ->join('sme_details', 'sme_details.sme_details_id', '=', 'job.job_sme_id')
                                        ->select('assign_job.*','job.*','internship.*','sme_details.*')
                                        ->where("user_id","=", $userid)
                                        ->where("job_type","=", "internship")
                                        ->where("job_status","=", "IN PROGRESS")
                                        ->get();
                        
                        $search_results=array($challenge_results,$internship_results);
                        return($search_results);
                    }
                }
            }
        }
        
    public function get_challenge_assigned_to_me($userid,$token){
        $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
    
        if($check_token_time){
        
            $check_role= $this->Functions->return_user_role($userid);
            if(count($check_role)==1){
            
                $role=$check_role[0]->user_role_role_id;
                if($role==1){
                    $challenge_results = DB::table('assign_job')
                                    ->join('job', 'job.job_id', '=', 'assign_job.job_id')
                                    ->join('challenges', 'challenges.challenge_job_id', '=', 'job.job_id')
                                    ->join('sme_details', 'sme_details.sme_details_id', '=', 'job.job_sme_id')
                                    ->select('assign_job.*','job.*','challenges.*','sme_details.*')
                                    ->where("user_id","=", $userid)
                                    ->where("job_type","=", "challenge")
                                    ->get();
                    
                    return($challenge_results);
                }
            }
        }
    }
    
    public function get_internship_assigned_to_me($userid,$token){
            $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
            if($check_token_time){
            
                $check_role= $this->Functions->return_user_role($userid);
                if(count($check_role)==1){
                
                    $role=$check_role[0]->user_role_role_id;
                    if($role==1){
                        $internship_results = DB::table('assign_job')
                                        ->join('job', 'job.job_id', '=', 'assign_job.job_id')
                                        ->join('internship', 'internship.internship_job_id', '=', 'job.job_id')
                                        ->join('sme_details', 'sme_details.sme_details_id', '=', 'job.job_sme_id')
                                        ->select('assign_job.*','job.*','internship.*','sme_details.*')
                                        ->where("user_id","=", $userid)
                                        ->where("job_type","=", "internship")
                                        ->get();
                        
                        return($internship_results);
                    }
                }
            }
        }
        
    public function get_job_details_byid($userid,$token,$jobid){
            $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
            if($check_token_time){
                
                $check_type = DB::table('job')
                                ->select('job_type')
                                ->where("job_id","=", $jobid)
                                ->get();
                            
                if(count($check_type)==1){
                
                    $type = $check_type[0]->job_type;
                    if($type=='challenge'){
                
                        $search_results = DB::table('job')
                                        ->join('challenges', 'challenges.challenge_job_id', '=', 'job.job_id')
                                        ->join('basic_user', 'basic_user.user_id', '=', 'job.job_user_id')
                                        ->join('sme_details', 'sme_details.sme_details_id', '=', 'job.job_sme_id')
                                        ->select('job.*','challenges.*','basic_user.*','sme_details.*')
                                        ->where("job_id","=", $jobid)
                                        ->get();
                                        
                        $challengeid = $search_results[0]->challenge_id;
                        
                        $if_assigned = DB::table('assign_job')
                                        ->join('basic_user', 'basic_user.user_id', '=', 'assign_job.user_id')
                                        ->select('assign_job.*','basic_user.*')
                                        ->where("challenge_id","=", $challengeid)
                                        ->get();
                        
                        if(count($if_assigned)==1){
                            $result=array($search_results,$if_assigned);
                            return($result);
                        }
                        else{        
                            $if_assigned=array();
                            $result=array($search_results,$if_assigned);
                            return($result);
                        }
                    }
                    else if($type=='internship'){
                        
                        $search_results = DB::table('job')
                                        ->join('internship', 'internship.internship_job_id', '=', 'job.job_id')
                                        ->join('basic_user', 'basic_user.user_id', '=', 'job.job_user_id')
                                        ->join('sme_details', 'sme_details.sme_details_id', '=', 'job.job_sme_id')
                                        ->select('job.*','internship.*','basic_user.*','sme_details.*')
                                        ->where("job_id","=", $jobid)
                                        ->get();
                                        
                            $empty_array=array();
                            $result=array($search_results,$empty_array);
                            return($result);
                    
                    }else{return"not internship";}
                }else{return"no type";} 
            }else{return"error token";}
        }
        
    public function post_comment($userid,$token,$msg,$jobid,$reply){
            $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
            if($check_token_time){
                $insert = DB::table('comments')->insert([
                            'user_id' => $userid,
                            'message' => $msg,
                            'job_id' => $jobid,
                            'reply' => $reply,
                            ]);
                
                return ($insert);
            }
        }
        
    public function get_count_comments_by_jobid($userid,$token,$jobid){
            $check_token_time= $this->Functions->check_user_token_time($userid, $token) ;
        
            if($check_token_time){
                $comments = DB::table('comments')
                            ->select('*')
                            ->where("job_id","=", $jobid)
                            ->get();
                
                $count_comments= $comments->count();
                
                return ($count_comments);
            }
        }
        
    public function get_all_documents($userid,$token){
            $check_token_time= $this->Functions->check_user_token_time($userid, $token);
        
            if($check_token_time){
                $check_role= $this->Functions->return_user_role($userid);
                if(count($check_role)==1){
                
                    $role=$check_role[0]->user_role_role_id;
                    
                    if($role==4){
                        $documents_profile = DB::table('sme_details')
                                        ->join('basic_user', 'basic_user.user_id', '=', 'sme_details.sme_details_userid')
                                        ->select('sme_details.*','basic_user.*')
                                        ->get();
                                    
                        $documents_challenge = DB::table('challenges')
                                        ->join('job', 'job.job_id', '=', 'challenges.challenge_job_id')
                                        ->join('basic_user', 'basic_user.user_id', '=', 'job.job_user_id')
                                        ->join('sme_details', 'sme_details.sme_details_id', '=', 'job.job_sme_id')
                                        ->select('challenges.*','job.*','basic_user.*','sme_details.*')
                                        ->get();
                
                        $documents=array($documents_profile,$documents_challenge);
                        return $documents;
                        
                    } {return"error role not admin";}
                }
            } {return "error token";}
        }
        
    public function get_user_info_company($myid,$token,$userid){
        $check_token_time= $this->Functions->check_user_token_time($myid, $token);
        
        if($check_token_time){
            $check_role= $this->Functions->return_user_role($myid);
            if(count($check_role)==1){
            
                $role=$check_role[0]->user_role_role_id;
                
                if($role==4){
                    $result = DB::table('basic_user')
                            ->join('sme_details', 'sme_details.sme_details_userid', '=', 'basic_user.user_id')
                            ->join('sme_social', 'sme_social.sme_social_company_id', '=', 'sme_details.sme_details_id')
                            ->select('basic_user.*','sme_details.*','sme_social.*')
                            ->where("user_id","=", $userid)
                            ->get();
                    
                    return $result;
                }
            }
        }
    }
        
    public function delete_document($userid,$token,$document_name,$document_type,$id_row){
            $check_token_time= $this->Functions->check_user_token_time($userid, $token);
            
            if($check_token_time){
               
                if($document_type=='profile'){
                  
                    DB::table('sme_details')->where("sme_details_id","=", $id_row)
                                            ->where("sme_details_company_profile","=", $document_name)
		                                    ->update([
                                            'sme_details_company_profile' => NULL,
                    ]);
                }
                else if($document_type=='challenge'){
                    DB::table('challenges')->where("challenge_id","=", $id_row)
                                            ->where("challenge_document","=", $document_name)
		                                    ->update([
                                            'challenge_document' => NULL,
                    ]);
                }
            }
        }
    
    public function get_notifications($userid,$token){
            $check_token_time= $this->Functions->check_user_token_time($userid, $token);
            
            if($check_token_time){
                $notifications= DB::table('notifications')
                            ->select("*")
                            ->where("notification_user_id","=", $userid)
                            ->get();
            
            return $notifications;
            
            }
        }
        
    public function fill_data(){
            $main_customers = DB::table('main_customers')
                            ->select("*")
                            ->get();
		
		    $industry_type = DB::table('industry_type')
                            ->select("*")
                            ->get();
                            
            $data= array($main_customers,$industry_type);
            return $data;
        }
    
    public function check_user_of_job($userid,$jobid){
        $user_sme_id = $this->Functions->get_sme_id_by_user_id($userid);
        $sme_id=$user_sme_id[0]->sme_details_id;
        $search_results = DB::table('job')
                            ->select("*")
                            ->where("job_id","=", $jobid)
                            ->where("job_user_id","=", $userid)
                            ->where("job_sme_id","=", $sme_id)
                            ->get();
		
		if(count($search_results)==1){
		    return true;
		}
    }
    
    
    
}

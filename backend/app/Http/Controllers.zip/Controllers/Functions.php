<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request; 
use Illuminate\Http\Response;
use App\Http\Requests;
use DateTime;
use Mail;
use Hash;
use Dompdf\Dompdf;

use Str;


class Functions extends Controller
{
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    }
	
	/**
     * Supdate option.
     *
     * @param  int  $id
     * @return Response
     */
     
    
     
    
    
    
    
    public function register_company($headquarter,$address1,$address2,$caddress,$cemail,$cname,$cType,$customer,$employees,$file,$iType,$link,$product,$social,$userid,$website){
        date_default_timezone_set("Asia/Beirut");
        $date = date("Y/m/d H:i:s");
        $string_customer="";$string_itype="";
       
       foreach ($customer as $value) {
            $string_customer.=$value.",";
        }

foreach ($iType as $value1) {
  $string_itype.=$value1.",";
}
    $if_user_sme_exist = DB::table('sme_details')
                        ->select('*')
                        ->where("sme_details_userid","=",$userid)
                        ->get();
    
    if(count($if_user_sme_exist)==0){
    
    
        $id=  DB::table('sme_details')->insertGetId([
                'sme_details_userid' => $userid,
                'sme_details_company_name' => $cname,
                'sme_details_company_website' => $website,
                'sme_details_company_email' => $cemail,
                'sme_details_company_address_country' => $caddress,
                'sme_details_headquarter' => $headquarter,
                'sme_details_company_address_line1' => $address1,
                'sme_details_company_address_line2' => $address2,
                'sme_details_industry_type' => $string_itype,
                'sme_details_company_type' => $cType,
                'sme_details_company_number_employee' => $employees,
                'sme_details_company_primary_product' => $product,
                'sme_details_company_main_customer' => $string_customer,
                       'sme_details_company_profile' => $file,
                'created_at' => $date,
                'updated_at' => null,
        ]);
           
           for($i=0;$i<count($social);$i++){
                $id2= DB::table('sme_social')->insert(['sme_social_company_id' => $id,'sme_social_type' => $social[$i],'sme_social_link' => $link[$i],'created_date' => $date,'updated_date' => null,]); 
               
           }
 
        if($id){return"submited";}else{return"error";}
    } else{return "user sme already exist";}
}
     
    public function post_challenge($userid, $token, $chname,$chtype,$chdesc,$chapproach,$chspec,$chtime,$chaffected,$chaffspec,$chcost,$chcostspec,$document,$chhear){
         $check_token_time= $this->check_user_token_time($userid, $token) ;
       
         if($check_token_time){
           
        
         date_default_timezone_set("Asia/Beirut");
         $date = date("Y/m/d H:i:s");
		 $sme_id= $this->get_sme_id_by_user_id($userid) ;
		 $sme_id=$sme_id[0]->sme_details_id;
		 
		 $id_job=  DB::table('job')->insertGetId([
                'job_user_id' => $userid,
                'job_sme_id' => $sme_id,
                'job_type' =>  'challenge',
                'job_active' => '1',
                'job_status' => 'PENDING REVIEW',
                'created_date' => $date,
                'updated_date' => null,
                
        ]); 
        
        $if_job_id_exist = DB::table('challenges')
                        ->select('*')
                        ->where("challenge_job_id","=",$id_job)
                        ->get();
    
            if(count($if_job_id_exist)==0){
        
                $challenge_id=  DB::table('challenges')->insertGetId([
                'challenge_job_id' => $id_job, 
                'challenge_name' => $chname,
                'challenge_type' =>  $chtype,
                'challenge_description' => $chdesc,
                'challenge_approach' => $chapproach,
                'challenge_approach_spec' => $chspec,
                'challenge_time' => $chtime,
                'challenge_comp_affected' => $chaffected,
                'challenge_comp_affected_spec' => $chaffspec,
                'challenge_cost' => $chcost,
                'challenge_cost_spec' => $chcostspec,
                'challenge_document' => $document,
                'challenge_hear' => $chhear,
                
                ]); 
                return $challenge_id;
            
            }else{return"error 3000";}
        }
        else{return"error token";}

    }
    
    public function post_internship($userid,$token,$startdate,$positionOutline,$location,$listDocuments,$enddate,$jobTitle,$experience,$department,$compensationSalary,$companydesc,$categorieStudent,$length,$major,$contact,$link){
    
         
         $startdate = date('Y-m-d', strtotime($startdate ));
         $enddate = date('Y-m-d', strtotime($enddate ));
        
      
        $check_token_time= $this->check_user_token_time($userid, $token) ;
   
         if($check_token_time){

        date_default_timezone_set("Asia/Beirut");
        $date = date("Y/m/d H:i:s");
		$sme_id = $this->get_sme_id_by_user_id($userid) ;
		$sme_id=$sme_id[0]->sme_details_id;
		 
		$id_job = DB::table('job')->insertGetId([
                'job_user_id' => $userid,
                'job_sme_id' => $sme_id,
                'job_type' =>  'internship',
                'job_active' => '1',
                'job_status' => 'PENDING REVIEW',
                'created_date' => $date,
                'updated_date' => null,
                
        ]); 
        
        $if_job_id_exist = DB::table('internship')
                        ->select('*')
                        ->where("internship_job_id","=",$id_job)
                        ->get();
    
        if(count($if_job_id_exist)==0){
        
            $internship_id = DB::table('internship')->insertGetId([
                'internship_job_id'                 => $id_job, 
                'internship_job_title'              => $jobTitle,
                'internship_outline'                => $positionOutline,
                'internship_categorie_students'     => $categorieStudent,
                'internship_prior_work_experience'  => $experience,
                'internship_compensation_salary'    => $compensationSalary,
                'internship_required_document'      => $listDocuments,
                'internship_brief_description'      => $companydesc,
                'internship_locations'              => $location,
                'internship_start_date'             => $startdate,
                'internship_end_date'               => $enddate,
                'internship_department'             => $department,
                'internship_length'                            => $length,
                'student_major'                     => $major,
                'contact_details'                   => $contact,
                'internship_link'                              => $link,
            ]); 
            return $internship_id;
        }else{echo"error1";}
     }else{echo"error";}
    }
    
    public function check_user_token_time ($id, $token){
        
         $token= md5($token) ;
         $times= time();
         
         $search_results = DB::table('basic_user')
                            ->select('*')
                            ->where("user_id","=", $id)
                            ->where("login_token","=", $token)
                            ->get();
                            
       if( count($search_results) == 1 ) {
            $timestamp= $search_results[0]->login_at;
            if($times - $timestamp < 60*60  ) return true;
            else return false;
       }
        
		 
     }
    
    public function get_jobs ($id, $token){
          
         $search_results = DB::table('job')
                            ->select("job_id")
                            ->where("job_user_id","=", $id)
                            ->get();
		 return $search_results;
     }
     
    public function get_sme_id_by_user_id($id){
         $search_results = DB::table('sme_details')
                            ->select("sme_details_id")
                            ->where("sme_details_userid","=", $id)
                            ->get();
		 return $search_results;
     }
     
    public function return_user_role($user_id){
         
         $search_results = DB::table('user_role')
                            ->select("user_role_role_id")
                            ->where("user_role_userid","=", $user_id)->where("active","=", 1)->get();
		 return $search_results;
         
     }
     
    public function if_new_user_exist($username,$email,$phone){   
        $data=array();$count=0;
    
        $users = DB::table('basic_user')->where("user_email","=",$email)->get();
        if(count($users)>0){$data = array(0,"Email Already In Use");$count++;}
        
        $users = DB::table('basic_user')->where("user_mobile","=",$phone)->get();
        if(count($users)>0){$data = array(0,"This Phone Number Is Already Registered To An Account");$count++;}
        
        $users = DB::table('basic_user')->where("user_username","=",$username)->get();
        if(count($users)>0){$data = array(0,"Username Already Registered");$count++;}
        
        if($count==0){$data = array(1,"ok");}
        
        return $data;

		
	}
     
    public function generate_login_token($username,$password){
         $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < 15; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    
    $times=time();
    $update = DB::table('basic_user')->where('user_username','=', $username)->where('user_password','=', $password)->update(['login_token' => md5($randomString) , 'login_at' =>$times]);
              
    return $randomString;
    }
    
    public function get_user_detail($userid,$token){
        
         $check_token_time= $this->check_user_token_time($userid, $token) ;
         $token=md5($token);
         if($check_token_time){
             $search_results = DB::table('basic_user')
                            ->join('user_role', 'user_role.user_role_userid', '=', 'basic_user.user_id')
                            ->join('roles', 'roles.role_id', '=', 'user_role.user_role_role_id')
                            ->select("basic_user.*","user_role.*","roles.*")
                            ->where("user_id","=", $userid)->where("login_token","=", $token)->get();
             return $search_results;
         }
         return "error";
         
         
        
    }
    
    public function get_company_detail($userid,$token){
      
         $check_token_time= $this->check_user_token_time($userid, $token) ;
         
         if($check_token_time){
             $token=md5($token);
             $search_results = DB::table('basic_user')
                            ->join('user_role', 'user_role.user_role_userid', '=', 'basic_user.user_id')
                            ->join('roles', 'roles.role_id', '=', 'user_role.user_role_role_id')
                            ->join('sme_details', 'sme_details.sme_details_userid', '=', 'basic_user.user_id')
                            ->select("basic_user.*","user_role.*","sme_details.*")
                            ->where("user_id","=", $userid)->where("login_token","=", $token)
                            ->get();
                         
                            
            $sme_id= $search_results[0]->sme_details_id;
        
            $social_links= DB::table('sme_social')
                        ->select('*')
                        ->where("sme_social_company_id","=",$sme_id)
                        ->get();
      

        $company_detail= array($search_results,$social_links);
        return $company_detail;
             
         } else{return"error";}
        
    }
    
    
    
    public function forgot_password($request){
       // $date = Carbon::parse($dt);
         $user = DB::table('basic_user')->where('user_email',$request->email)->first();
         $checkdate = DB::table('reset_password')->select('created_at')->where('email',$user);
       /*  if($checkdate->isYesterday()){
                         return redirect()->back()->withErrors(['error'=>'past date!']);
         }
         if($checkdate)*/
        if($user == null){
            return redirect()->back()->withErrors(['error'=>'error email not found!']);
        }
        
        $token = Str::random(30);
        
      //  $link = config('base_url') . 'reset/' . $token ;//. '?email=' . urlencode($user);
        DB::table('reset_password')->insert(['email' => $request->email, 'token' => $token, 'created_at' => date('Y-m-d H:i:s') ]);
        
        Mail::send('verify',['token' => $token], function($message) use ($request)
        {
           // $message->from($request->email);
            $message->to('darakjikarim@gmail.com');
            $message->subject('change password');
        });
        
        return redirect()->back()->with(['success' => 'email sent']);
        
    }
    
    public function resetpassword(Request $request){
        $request->validate([
      'email' => 'required|email|exists:users',
      'password' => 'required|string|min:6|confirmed',
      'password_confirmation' => 'required',

  ]);
 
        
       
        $password = Hash::make($request->password);
        $user = DB::table('basic_user')->where('user_email',$request->email)->update(['user_password' => $password]);
        
        return redirect()->back()->with(['success' => 'Password changed']);


    }
    
    public function update_user($userid,$token,$name,$phone,$office_number,$job){
        
        $check_token_time= $this->check_user_token_time($userid, $token) ;
        $token=md5($token);
         if($check_token_time){
         $update = DB::table('basic_user')->where('user_id','=', $userid)->where('login_token','=', $token)->update(['user_name' => $name , 'user_mobile' =>$phone,'user_office_number'=>$office_number,'user_role'=>$job]);
         return $update;
         }else{return"error";}
         
         
    }
    
    public function update_company($userid,$token,$headquarter,$address1,$address2,$caddress,$cemail,$cname,$cType,$customer,$employees,$file,$iType,$link,$product,$social,$website){
        
        $check_token_time= $this->check_user_token_time($userid, $token) ;
         if($check_token_time){
           
           
             date_default_timezone_set("Asia/Beirut");
        $date = date("Y/m/d H:i:s");
        
        $string_customer="";

        if (array_key_exists('Government Sector', $customer) && $customer["Government Sector"]==true ) {$string_customer.="Government Sector,";}
        if (array_key_exists('Non-profit Organisations', $customer) && $customer["Non-profit Organisations"]==true ) {$string_customer.="Non-profit Organisations,";}
        if (array_key_exists('Other Companies', $customer) && $customer["Other Companies"]==true ) {$string_customer.="Other Companies,";}
        if (array_key_exists('Individuals', $customer) && $customer["Individuals"]==true ) {$string_customer.="Individuals,";}
        if (array_key_exists('Banks and Financial Sector', $customer) && $customer["Banks and Financial Sector"]==true ) {$string_customer.="Banks and Financial Sector,";}
        if (array_key_exists('International', $customer) && $customer["International"]==true ) {$string_customer.="International,";}
        
        
        $update = DB::table('sme_details')->where('sme_details_userid','=', $userid)->update(['sme_details_company_name' => $cname , 'sme_details_company_website' => $website, 'sme_details_company_email' => $cemail,'sme_details_company_address_country' => $caddress,'sme_details_headquarter' => $headquarter,'sme_details_company_address_line1' => $address1,'sme_details_company_address_line2' => $address2,'sme_details_industry_type' => $iType,'sme_details_company_type' => $cType,'sme_details_company_number_employee' => $employees,'sme_details_company_primary_product' => $product,'sme_details_company_main_customer' => $string_customer,'sme_details_company_profile' => '1','updated_at' => $date]);
        
        DB::table('sme_social')->where('sme_social_company_id', '=', $userid)->delete();

           for($i=0;$i<count($social);$i++){
                $id2= DB::table('sme_social')->insert(['sme_social_company_id' => $userid,'sme_social_type' => $social[0],'sme_social_link' => $link[0],'created_date' => $date,'updated_date' => null,]); 
               
           }
 
        if($userid){return"submited";}else{return"error";}
           
           
           
         }else{return"errffor";}
        
    }
    
    public function get_users_by_role($role){
        
             $search_results = DB::table('basic_user')
                            ->join('user_role', 'user_role.user_role_userid', '=', 'basic_user.user_id')
                            ->join('roles', 'roles.role_id', '=', 'user_role.user_role_role_id')
                            ->select("basic_user.*","user_role.*","roles.*")
                            ->where("user_role.user_role_role_id","=", $role)->get();
             return $search_results;
         
         
         
        
    }
    
    public function get_admin_dashboard($userid,$token){
        
        $check_token_time= $this->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
          $check_role= $this->return_user_role($userid);
          if(count($check_role)==1){
              $role=$check_role[0]->user_role_role_id;
              if($role==4){
                //admin
               
                $internship_search_results = DB::table('job')
                                            ->join('internship', 'internship.internship_job_id', '=', 'job.job_id')
                                            ->join('sme_details', 'sme_details.sme_details_id', '=', 'job.job_sme_id')
                                            ->select('job.*','internship.*','sme_details.*')
                                            ->where("job_status","=", "PENDING REVIEW")
                                            ->where("job_type","=", "internship")
                                            ->orderBy('created_date', 'asc')
                                            ->get();
                                
                $challenge_search_results = DB::table('job')
                                            ->join('challenges', 'challenges.challenge_job_id', '=', 'job.job_id')
                                            ->join('sme_details', 'sme_details.sme_details_id', '=', 'job.job_sme_id')
                                            ->leftjoin('assign_job', 'assign_job.challenge_id', '=', 'challenges.challenge_id')
                                            ->leftjoin('basic_user', 'basic_user.user_id', '=', 'assign_job.user_id')
                                            ->select('job.*','challenges.*','sme_details.*','assign_job.*','basic_user.*')
                                            ->where("job.job_status","=", "PENDING REVIEW")
                                            ->where("job.job_type","=", "challenge")
                                            ->get();
                
                $count_comments = DB::table('comments')
                                ->select('job_id', DB::raw('count(*) as total'))
                                ->groupBy('job_id')
                                ->pluck('total','job_id')->all();
                
                $result=array($internship_search_results,$challenge_search_results,$count_comments);
                return $result; 
                
              }
              else{return"can't display data";}
          }
            
            
        }
        
        
    }
    
    public function get_kaust_talents($userid,$token){
        
        $check_token_time= $this->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
          $check_role= $this->return_user_role($userid);
          if(count($check_role)==1){
              $role=$check_role[0]->user_role_role_id;
              if($role==4){
                  //admin
             $all_sme= $this->get_users_by_role("3");
             return $all_sme;
                
              }
              else{return"can't display data";}
          }
            
            
        }
        
        
    }
    
    public function respond_challenge($userid,$token,$job_id,$action){
        
        $check_token_time= $this->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
          $check_role= $this->return_user_role($userid);
          if(count($check_role)==1){
              $role=$check_role[0]->user_role_role_id;
              if($role==4){
                  //admin
           $update = DB::table('job')->where('job_id','=', $job_id)->update(['job_status' => $action ]);
           return "done";

                
              }
              else{return"can't display data";}
          }
            
            
        }
        
        
    }
    
    public function get_talent_dashboard($userid,$token){
        
        $check_token_time= $this->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
          $check_role= $this->return_user_role($userid);
          if(count($check_role)==1){
              $role=$check_role[0]->user_role_role_id;
              if($role==2){
                  //TALENT
                  
                  
                  $pending_challenge = DB::table('job')
                                            ->join('challenges', 'challenges.challenge_job_id', '=', 'job.job_id')
                                            ->select('job.*','challenges.*')
                                            ->where("job_status","=", "on_going")
                                            ->where("job_type","=", "challenge")
                                            ->get();
                                
                  $ongoing_challenge = DB::table('job')
                                            ->join('challenges', 'challenges.challenge_job_id', '=', 'job.job_id')
                                            ->select('job.*','challenges.*')
                                            ->where("job_status","=", "PENDING REVIEW")
                                            ->where("job_type","=", "challenge")
                                            ->get();
                                            
                $result=array($pending_challenge,$ongoing_challenge);
                return $result; 
          

                
              }
              else{return"can't display data";}
          }
            
            
        }
        
    }
    
    public function get_student_dashboard($userid,$token){
        
        $check_token_time= $this->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
          $check_role= $this->return_user_role($userid);
          if(count($check_role)==1){
              $role=$check_role[0]->user_role_role_id;
              if($role==1){
                  //TALENT
                  
                  $internships = DB::table('job')
                                            ->join('internship', 'internship.internship_job_id', '=', 'job.job_id')
                                            ->select('job.*','internship.*')
                                            ->where("job.job_type","=", "internship")
                                            ->get();
                return $internships; 
                
              }
              else{return"can't display data";}
          }
            
            
        }
        
    }
    
    public function check_self_signed_nda($userid,$token){
        
        $check_token_time= $this->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            $sme_id= $this->get_sme_id_by_user_id($userid) ;
	    	$sme_id=$sme_id[0]->sme_details_id;
	    	
	    	
	    	 $result = DB::table('signed_nda')
                      ->select('*')
                      ->where("user_id","=", $userid)
                      ->where("sme_id","=", $sme_id)
                      ->get();
                return $result; 
            
            
            
        }
        
    }
    
    public function agree_guidline($userid,$token,$tick){
        $check_token_time= $this->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            $sme_id= $this->get_sme_id_by_user_id($userid) ;
	    	$sme_id=$sme_id[0]->sme_details_id;
	    	date_default_timezone_set("Asia/Beirut");
        $date = date("Y/m/d H:i:s");
	    	
	    if($tick==1){
	        
	        DB::table('agree_guidline')->insert([
                      'user_id' => $userid,'sme_id' => $sme_id,'created_date' => $date,
        ]);
	        
	        
	    }
	    
	    return"proceed";
	    
            
            
            
            
        }
    }
    
    public function get_agree_guidline($userid,$token){
        
        $check_token_time= $this->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            $sme_id= $this->get_sme_id_by_user_id($userid) ;
	    	$sme_id=$sme_id[0]->sme_details_id;
	    	
	    	
	    	 $result = DB::table('agree_guidline')
                      ->select('*')
                      ->where("user_id","=", $userid)
                      ->where("sme_id","=", $sme_id)
                      ->get();
                return $result; 
            
            
            
        }
        
    }
    
     public function generate_nda_pdf($userid,$token,$date,$cname,$chead,$job_title,$country,$a1,$a2,$email){
      $check_token_time= $this->check_user_token_time($userid, $token);
      if($check_token_time){
          
          $html="This is an NDA Template <br>
          Date:$date <br>
          Company Name:$cname <br>
          Company Head Quarter:$chead <br>
          Job Title:$job_title <br>
          Country:$country <br>
          Address 1:$a1 <br>
          Address 2:$a2 <br>
          Email:$email <br>
          <br>
          <br>
          <br>
          <br>
          Sign Here <br><br>
          --------------
          ";
        $file_name="$userid-$token.pdf";  
        $dompdf = new DOMPDF();
        $dompdf->loadHtml($html);
        $dompdf->render();
        $output = $dompdf->output();
        file_put_contents('uploads/nda/'.$file_name , $output);
        return"http://162.241.73.161/~kaustportal/uploads/nda/$file_name";
          
      }
      
        
    }
    
     function deactivate_user($userid,$token,$id_to_delete){
         
         $check_token_time= $this->check_user_token_time($userid, $token) ;
        
        if($check_token_time){
            
          $check_role= $this->return_user_role($userid);
          if(count($check_role)==1){
              $role=$check_role[0]->user_role_role_id;
              if($role==4){
            
             $update = DB::table('basic_user')->where('user_id','=', $userid)->update(['user_active' => 2]);
             $update = DB::table('job')->where('job_user_id','=', $userid)->update(['job_active' => 0]);

 
 
              }
              else{return"can't display data";}
          }
            
            
        }
         

  
  
  
     }
         
     
     
     
     
}
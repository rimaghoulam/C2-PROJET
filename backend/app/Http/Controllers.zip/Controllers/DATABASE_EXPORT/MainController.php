<?php
namespace App\Http\Controllers\DATABASE_EXPORT;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request; 
use Illuminate\Http\Response;
use Session;
use Redirect;
use Dompdf\Dompdf;

class MainController extends Controller
{
    
   
    
    public function export_database($request){
        
         $get_all_table_query = "SHOW TABLES";
    $result = DB::select(DB::raw($get_all_table_query));

    $tables = [
        'account_activation',
        'admin_notifications',
        'agree_guidline',
        'assign_job',
        'basic_user',
        'challenges',
        'challenges_documents',
        'comments',
        'contact_us_form',
        'failed_jobs',
        'icons',
        'industry_details',
        'industry_profiles',
        'industry_social',
        'industry_type',
        'industry_users',
        'internship',
        'job',
        'job_status_log',
        'main_customers',
        'media',
        'menu',
        'menu_item',
        'migrations',
        'notifications',
        'notification_template',
        'option_list',
        'pages',
        'page_components',
        'password_resets',
        'request_meeting',
        'reset_password',
        'roles',
        'settings',
        'signed_nda',
        'sliders',
        'social_media',
        'testimonials',
        'users',
        'users_from_admin_activation',
        'user_role',
        'websockets_statistics_entries'
        
    ];

    $structure = '';
    $data = '';
    foreach ($tables as $table) {
        $show_table_query = "SHOW CREATE TABLE " . $table . "";

        $show_table_result = DB::select(DB::raw($show_table_query));

        foreach ($show_table_result as $show_table_row) {
            $show_table_row = (array)$show_table_row;
            $structure .= "\n\n" . $show_table_row["Create Table"] . ";\n\n";
        }
        $select_query = "SELECT * FROM " . $table;
        $records = DB::select(DB::raw($select_query));

        foreach ($records as $record) {
            $record = (array)$record;
            $table_column_array = array_keys($record);
            foreach ($table_column_array as $key => $name) {
                $table_column_array[$key] = '`' . $table_column_array[$key] . '`';
            }

            $table_value_array = array_values($record);
            $data .= "\nINSERT INTO $table (";

            $data .= "" . implode(", ", $table_column_array) . ") VALUES \n";

            foreach($table_value_array as $key => $record_column)
                $table_value_array[$key] = addslashes($record_column);

            $data .= "('" . implode("','", $table_value_array) . "');\n";
        }
    }
    $file_name = __DIR__ . '/database_backup_on.sql';
    $file_handle = fopen($file_name, 'w + ');

    $output = $structure . $data;
    fwrite($file_handle, $output);
    fclose($file_handle);
    
    
    header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($file_name));
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
           header('Pragma: public');
           header('Content-Length: ' . filesize($file_name));
           //ob_clean();
           flush();
           readfile($file_name);
           unlink($file_name);
    
    }
    
   

    
}
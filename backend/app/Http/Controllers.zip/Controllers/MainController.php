<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Functions;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request; 
use Illuminate\Http\Response;
use Session;
use Redirect;
use Dompdf\Dompdf;

class MainController extends Controller
{
    
      protected $Functions;
    public function __construct(Functions $Functions)
    {
        $this->Functions = $Functions;
    }
    
   
    
    
    
     public function Register_Company($request)
    {
       $headquarter= $request->input('headquarter'); $address1= $request->input('address1');$address2 = $request->input('address2');$caddress = $request->input('cAddress');$file = $request->input('file');$cemail = $request->input('cEmail');$cname = $request->input('cName');$cType= $request->input('cType');$customer = $request->input('customer');$employees = $request->input('employees');$iType = $request->input('iType');$link = $request->input('link');$product= $request->input('product');$social = $request->input('social');$userid = $request->input('userid');$website = $request->input('website');
       $insert_user = $this->Functions->register_company($headquarter,$address1,$address2,$caddress,$cemail,$cname,$cType,$customer,$employees,$file,$iType,$link,$product,$social,$userid,$website);
	   return json_encode($insert_user);
	 
    }
    
    
    
    public function upload_image($request)
    {
        $rand=rand(1000,100000);$rand2=rand(1000,100000);$rand1=$rand*$rand2;
$filename = $rand1."-profile-".$_FILES['file']['name'];
$ffname=$_FILES['file']['name'];
$location = "uploads/".$filename;
$uploadOk = 1;
$imageFileType = pathinfo($location,PATHINFO_EXTENSION);
$valid_extensions = array("jpg","jpeg","png","pdf");
if( !in_array(strtolower($imageFileType),$valid_extensions) ) {$uploadOk = 0;}
if($uploadOk == 0){ echo 0;}else{
   /* Upload file */
   if(move_uploaded_file($_FILES['file']['tmp_name'],$location)){
      echo $location;
   }else{
      echo 0;
   }
}
  

        
    }
    
    public function Post_Challenge($request)
    {
	    $userid = $request->input('userid');
	    $token = $request->input('token');
	    $chname = $request->input('challengeName');
	    $chtype = $request->input('challengeType');
	    $chdesc = $request->input('challengeDescription');
	    $chapproach = $request->input('approach');
	    $chspec = $request->input('approachChallSpecification');
	    $chtime = $request->input('challengeTime');
	    $chaffected = $request->input('companyAffected');
	    $chaffspec = $request->input('companyAffectedSpecification');
	    $chcost = $request->input('cost');
	    $chcostspec = $request->input('costSpecification');
	    $document = $request->input('files');
	    $chhear = $request->input('hear');
	    $insert_challenge = $this->Functions->post_challenge($userid, $token, $chname,$chtype,$chdesc,$chapproach,$chspec,$chtime,$chaffected,$chaffspec,$chcost,$chcostspec,$document,$chhear);
        return json_encode($insert_challenge);
    }
    
    public function Post_Internship($request)
    {
        $userid = $request->input('userid');
        $token = $request->input('token');
        $startdate = $request->input('startdate');
        $positionOutline = $request->input('positionOutline');
        $location = $request->input('location');
        $listDocuments = $request->input('listDocuments');
        $enddate = $request->input('enddate');
        $jobTitle = $request->input('jobTitle');
        $experience = $request->input('experience');
        $department = $request->input('department');
        $compensationSalary = $request->input('compensationSalary');
        $companydesc = $request->input('companyDesc');
        $categorieStudent = $request->input('categoryStudent');
        $length = $request->input('length');
        $major = $request->input('major');
        $contact = $request->input('contact');
        $link = $request->input('link');
        $insert_internship = $this->Functions->post_internship($userid,$token,$startdate,$positionOutline,$location,$listDocuments,$enddate,$jobTitle,$experience,$department,$compensationSalary,$companydesc,$categorieStudent,$length,$major,$contact,$link);
        return json_encode($insert_internship);
    }
    
    public function Get_User_Detail($request){
        $userid = $request->input('userid');
        $token = $request->input('token');
        $user_detail = $this->Functions->get_user_detail($userid,$token);
        return json_encode($user_detail);
    }
    
    public function Get_Company_Detail($request){
        $userid = $request->input('userid');
        $token = $request->input('token');
        $user_detail = $this->Functions->get_company_detail($userid,$token);
        return json_encode($user_detail);
    }
    
    
    public function Update_User_Detail($request){
       $userid = $request->input('userid');$token = $request->input('token');
       $name = $request->input('name');
       $country_code_1 = $request->input('country_code_1');
       $phone = $request->input('phone');$phone= $country_code_1." ".$phone;
       $country_code_2 = $request->input('country_code_2');
       $office_number= $request->input('office_number');$office_number= $country_code_2." ".$office_number;
       $job = $request->input('job');
       
	   
	   $insert_user = $this->Functions->update_user($userid,$token,$name,$phone,$office_number,$job);
	   return json_encode($insert_user);
    }
    
    public function Update_Company_Detail($request){
       $token = $request->input('token');
       $headquarter= $request->input('headquarter');$address1= $request->input('address1');$address2 = $request->input('address2');$caddress = $request->input('cAddress');$cemail = $request->input('cEmail');$cname = $request->input('cName');$cType= $request->input('cType');
       $customer = $request->input('customer');$employees = $request->input('employees');$file = $request->input('file');$iType = $request->input('iType');$link = $request->input('link');$product= $request->input('product');
       $social = $request->input('social');$userid = $request->input('userid');$website = $request->input('website');
       $insert_user = $this->Functions->update_company($userid,$token,$headquarter,$address1,$address2,$caddress,$cemail,$cname,$cType,$customer,$employees,$file,$iType,$link,$product,$social,$website);
	   return json_encode($insert_user);
    }
    
    
    
    
    public function Forget_Password($request)
    {
        
    }
    
    
    public function get_admin_dashboard($request){
        $userid = $request->input('userid');$token = $request->input('token');
        $dashboard_page = $this->Functions->get_admin_dashboard($userid,$token);
	    return json_encode($dashboard_page);
    }
    
    public function get_kaust_talents($request){
        $userid = $request->input('userid');$token = $request->input('token');
        $dashboard_page = $this->Functions->get_kaust_talents($userid,$token);
	    return json_encode($dashboard_page);
    }
    
    public function respond_challenge($request){
        $userid = $request->input('userid');$token = $request->input('token');$job_id = $request->input('job_id');$action = $request->input('action');
        $dashboard_page = $this->Functions->respond_challenge($userid,$token,$job_id,$action);
	    return json_encode($dashboard_page);
        
    }
    
    public function Get_Talent_Dashboard($request){
        $userid = $request->input('userid');$token = $request->input('token');
        $dashboard_page = $this->Functions->get_talent_dashboard($userid,$token);
	    return json_encode($dashboard_page);
    }
    
    public function Get_Student_Dashboard($request){
        $userid = $request->input('userid');$token = $request->input('token');
        $dashboard_page = $this->Functions->get_student_dashboard($userid,$token);
	    return json_encode($dashboard_page);
    }
    
    public function Download_PDF($request){
        
        $file = "http://162.241.73.161/~kaustportal/uploads/226949326-profile-fb.jpg";
        return response()->download($file);
        
    }
    
    public function check_self_signed_nda($request){
        $userid = $request->input('userid');$token = $request->input('token');
        $signed_nda = $this->Functions->check_self_signed_nda($userid,$token);
	    return json_encode($signed_nda);
    }
    
    public function agree_guidline($request){
        $userid = $request->input('userid');$token = $request->input('token');$tick = $request->input('tick');
        $agree_guidline = $this->Functions->agree_guidline($userid,$token,$tick);
	    return json_encode($agree_guidline);
    }
    
    public function get_agree_guidline($request){
        $userid = $request->input('userid');$token = $request->input('token');
        $agree_guidline = $this->Functions->get_agree_guidline($userid,$token);
	    return json_encode($agree_guidline);
    }
    
    public function generate_nda_pdf($request){
        $userid = $request->input('userid');$token = $request->input('token');$date = $request->input('date');
        $cname = $request->input('company_name');$chead = $request->input('company_head');$job_title = $request->input('job_title');
        $country = $request->input('country');$a2 = $request->input('a2');$a1 = $request->input('a1');$email = $request->input('email');
        
        $generate_nda_pdf = $this->Functions->generate_nda_pdf($userid,$token,$date,$cname,$chead,$job_title,$country,$a1,$a2,$email);
	    return json_encode($generate_nda_pdf);
    }
    
    
    public function deactivate_user($request){
        $userid = $request->input('userid');$token = $request->input('token');$id_to_delete = $request->input('id_to_delete');
        $deactivate_user = $this->Functions->deactivate_user($userid,$token,$id_to_delete);
	    return json_encode($deactivate_user);
    }
    
    
      
    
    
}